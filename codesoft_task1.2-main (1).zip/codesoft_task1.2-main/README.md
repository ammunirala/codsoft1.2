# codesoft_task1.2
making a website with the help of HTML,CSS.
